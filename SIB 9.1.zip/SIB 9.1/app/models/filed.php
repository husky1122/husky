<?
class Filed extends AppModel {
	
  //var $belongsTo = 'Post';
   var $name = 'Filed';
   //  var $hasOne = 'Post';
   var $hasMany = 'Multi';   	
}

