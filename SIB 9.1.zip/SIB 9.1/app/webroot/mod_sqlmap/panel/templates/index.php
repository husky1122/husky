<?php

	include ("header.php");
	include ("main.php");
	include ("footer.php");
?>